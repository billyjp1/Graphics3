package solution.shape;

/**
 * @author ags
 */
public class Cylinder extends Shape {

	private static final long serialVersionUID = 3256437006337718072L;

	/**
	 * Required for IO
	 */
	public Cylinder() {}

	/**
	 * @see solution.shape.Shape#buildMesh()
	 */
	public void buildMesh() {
		// TODO: Build mesh 
	}
}
