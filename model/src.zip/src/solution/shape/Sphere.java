package solution.shape;

/**
 * @author ags
 */
public class Sphere extends Shape {

	private static final long serialVersionUID = 3256437006337718072L;

	/**
	 * Required for IO
	 */
	public Sphere() {}

	/**
	 * @see solution.shape.Shape#buildMesh()
	 */
	public void buildMesh() {
		//TODO: Build mesh
	}

}
